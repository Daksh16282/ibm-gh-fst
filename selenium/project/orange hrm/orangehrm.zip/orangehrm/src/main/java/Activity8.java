import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Activity8 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");

        // ----------------------------------------------------------------------------------------
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        // -----------------------------------------------------------------------------------------------------

        WebElement applyLeave = webDriver.findElement(By.xpath("//span[text()='Apply Leave']"));
        builder.click(applyLeave).pause(3000).build().perform();

        WebElement leaveType = webDriver.findElement(By.xpath("//select[@id='applyleave_txtLeaveType']"));
        Select leaveSelect = new Select(leaveType);

        WebElement fromDate = webDriver.findElement(By.id("applyleave_txtFromDate"));
        WebElement toDate = webDriver.findElement(By.id("applyleave_txtToDate"));

        leaveSelect.selectByIndex(1);
        fromDate.clear();
        String fromDateSent = "2026-08-10";
        fromDate.sendKeys(fromDateSent);
        toDate.clear();
        String toDateSent = "2028-12-31";
        toDate.sendKeys(toDateSent);

        WebElement applyBtn = webDriver.findElement(By.id("applyBtn"));
        builder.click(applyBtn).pause(8000).build().perform();

        WebElement myLeaves = webDriver.findElement(By.id("menu_leave_viewMyLeaveList"));
        builder.click(myLeaves).pause(3000).build().perform();

        List<WebElement> leaveTableRows = webDriver.findElements(By.xpath("//table/tbody/tr"));
        for (int i = 0; i < leaveTableRows.size() - 1; i++) {
            String dateVal = leaveTableRows.get(i).findElement(By.xpath("./td[1]/a")).getText();
            if (dateVal.substring(0, 10).equals(fromDateSent)) {
                String status = leaveTableRows.get(i).findElement(By.xpath("./td[6]/a")).getText();
                System.out.println("Status is : " + status);
                System.out.println();
                break;
            }

        }

        // for (WebElement row : leaveTableRows) {
        // // System.out.println(row.getText());
        // String dateVal = row.findElement(By.xpath("./td[1]/a")).getText();
        // // System.out.println(dateVal);
        // if (dateVal.substring(0, 10).equals(fromDateSent)) {
        // String status = row.findElement(By.xpath("./td[6]/a")).getText();
        // System.out.println("Status is : " + status);
        // }

        // }

        webDriver.quit();
    }
}
