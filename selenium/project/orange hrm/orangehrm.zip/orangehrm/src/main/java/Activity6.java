import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Activity6 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");

        // ----------------------------------------------------------------------------------------
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        // -----------------------------------------------------------------------------------------------------

        WebElement directory = webDriver.findElement(By.id("menu_directory_viewDirectory"));
        directory.click();

        By headingPath = By.xpath("//div[@class='head']/h1");
        WebElement headingElement = webDriver.findElement(headingPath);
        System.out.println("Text is : " + headingElement.getText());

        webDriver.quit();
    }
}
