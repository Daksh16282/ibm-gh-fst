import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Activity1 {
    public static void main(String[] args) {

        WebDriver webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
        String title = webDriver.getTitle();
        if (title.equals("OrangeHRM")) {
            System.out.println("Title is : " + title);
            webDriver.quit();
        } else {
            System.out.println("Title not found");
        }
    }
}
