import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Activity7 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");

        // ----------------------------------------------------------------------------------------
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        // -----------------------------------------------------------------------------------------------------

        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement qualificationTab = webDriver.findElement(By.xpath("(//a[text()='Qualifications'])[2]"));
        builder.click(qualificationTab).pause(3000).build().perform();

        WebElement addButton = webDriver.findElement(By.id("addWorkExperience"));
        builder.click(addButton).pause(3000).build().perform();

        WebElement companyName = webDriver.findElement(By.id("experience_employer"));
        WebElement jobTitle = webDriver.findElement(By.id("experience_jobtitle"));

        WebElement fromDate = webDriver.findElement(By.id("experience_from_date"));
        WebElement toDate = webDriver.findElement(By.id("experience_to_date"));

        companyName.sendKeys("IBM");
        jobTitle.sendKeys("QE");
        fromDate.clear();
        fromDate.sendKeys("2026-01-01");
        toDate.clear();
        toDate.sendKeys("2028-12-31");

        WebElement saveButton = webDriver.findElement(By.id("btnWorkExpSave"));
        builder.click(saveButton).pause(3000).build().perform();

        webDriver.quit();
    }
}
