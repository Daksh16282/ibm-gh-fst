import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Activity5 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");

        // ----------------------------------------------------------------------------------------
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        // -----------------------------------------------------------------------------------------------------

        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement editBtn = webDriver.findElement(By.id("btnSave"));
        builder.click(editBtn).pause(3000).build().perform();

        WebElement firstName = webDriver.findElement(By.id("personal_txtEmpFirstName"));
        WebElement lastName = webDriver.findElement(By.id("personal_txtEmpLastName"));
        WebElement maleButton = webDriver.findElement(By.id("personal_optGender_1"));
        WebElement nationalitySelect = webDriver.findElement(By.id("personal_cmbNation"));
        Select selectNation = new Select(nationalitySelect);
        WebElement dob = webDriver.findElement(By.id("personal_DOB"));
        WebElement btnSave = webDriver.findElement(By.id("btnSave"));

        firstName.clear();
        firstName.sendKeys("First");
        lastName.clear();
        lastName.sendKeys("Last");
        maleButton.click();
        selectNation.selectByIndex(4);
        dob.clear();
        dob.sendKeys("2026-07-01");
        builder.click(btnSave).pause(3000).build().perform();

        webDriver.quit();
    }
}
