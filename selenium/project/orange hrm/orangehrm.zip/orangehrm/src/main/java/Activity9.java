import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Activity9 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");

        // ----------------------------------------------------------------------------------------
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        // -----------------------------------------------------------------------------------------------------

        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement emergencyContact = webDriver.findElement(By.xpath("//a[text()='Emergency Contacts']"));
        builder.click(emergencyContact).pause(3000).build().perform();

        List<WebElement> contacts = webDriver.findElements(By.xpath("//table/tbody/tr"));
        for (WebElement contact : contacts) {
            System.out.println(contact.getText());
        }
        webDriver.quit();
    }
}
