import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Activity2 {

    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
        WebElement headerImage = webDriver.findElement(By.xpath("//div[@id='divLogo']/img"));
        System.out.println("Image source is : " + headerImage.getAttribute("src"));
        webDriver.quit();
    }
}
