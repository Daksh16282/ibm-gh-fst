package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Then;

public class Activity9_C extends BaseClass{

        Actions builder = new Actions(webDriver);

    @Then("user clicked the emergencyContacts tab and see the results")
    public void click_emergency_tab_and_see_results(){
        WebElement emergencyContact = webDriver.findElement(By.xpath("//a[text()='Emergency Contacts']"));
        builder.click(emergencyContact).pause(3000).build().perform();

        List<WebElement> contacts = webDriver.findElements(By.xpath("//table/tbody/tr"));
        // for (WebElement contact : contacts) {
        //     System.out.println(contact.getText());
        // }
        assertEquals(contacts.size(), 4);
    
    }
    
}
