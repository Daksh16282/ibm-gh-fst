package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Then;

public class Activity2_C extends BaseClass {
    @Then("url of header is printed")
    public void check_header_url() {
        WebElement headerImage = webDriver.findElement(By.xpath("//div[@id='divLogo']/img"));
        assertEquals(headerImage.getAttribute("src"),
                "https://hrm.alchemy.hguy.co/symfony/web/webres_618e67a57beec1.83834480/themes/default/images/login/logo.png");

    }
}
