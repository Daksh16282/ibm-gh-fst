package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class Activity2_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }

    @Test
    public void assertHeaderUrl() {
        WebElement headerImage = webDriver.findElement(By.xpath("//div[@id='divLogo']/img"));
        assertEquals(headerImage.getAttribute("src"),
                "https://hrm.alchemy.hguy.co/symfony/web/webres_618e67a57beec1.83834480/themes/default/images/login/logo.png");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
