package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

public class Activity3_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }

    @Test
    public void assertLogIn() {
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();

        assertEquals(webDriver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
