package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity6_C extends BaseClass {

    @When("user clicked the directory tab")
    public void click_directory_tab() {
        WebElement directory = webDriver.findElement(By.id("menu_directory_viewDirectory"));
        directory.click();
    }

    @Then("user fetched the heading text and check value")
    public void assert_heading() {
        By headingPath = By.xpath("//div[@class='head']/h1");
        WebElement headingElement = webDriver.findElement(headingPath);
        assertEquals(headingElement.getText(), "Search Directory");
    }

}
