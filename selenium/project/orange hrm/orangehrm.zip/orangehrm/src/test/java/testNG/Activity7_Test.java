package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

import java.util.List;

public class Activity7_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }

    @Test
    public void assertAddQualification() {
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();

        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement qualificationTab = webDriver.findElement(By.xpath("(//a[text()='Qualifications'])[2]"));
        builder.click(qualificationTab).pause(3000).build().perform();

        List<WebElement> results = webDriver.findElements(By.xpath("//table[@class='table hover']/tbody/tr"));
        int oldSize = results.size();

        WebElement addButton = webDriver.findElement(By.id("addWorkExperience"));
        builder.click(addButton).pause(3000).build().perform();

        WebElement companyName = webDriver.findElement(By.id("experience_employer"));
        WebElement jobTitle = webDriver.findElement(By.id("experience_jobtitle"));

        WebElement fromDate = webDriver.findElement(By.id("experience_from_date"));
        WebElement toDate = webDriver.findElement(By.id("experience_to_date"));

        companyName.sendKeys("IBM");
        jobTitle.sendKeys("QE");
        fromDate.clear();
        fromDate.sendKeys("2026-01-01");
        toDate.clear();
        toDate.sendKeys("2028-12-31");

        WebElement saveButton = webDriver.findElement(By.id("btnWorkExpSave"));
        builder.click(saveButton).pause(3000).build().perform();

        results = webDriver.findElements(By.xpath("//table[@class='table hover']/tbody/tr"));

        assertEquals(results.size(), oldSize + 1, "Old size is : " + oldSize);

    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
