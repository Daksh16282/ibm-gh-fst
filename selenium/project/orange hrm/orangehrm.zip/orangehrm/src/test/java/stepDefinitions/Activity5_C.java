package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity5_C extends BaseClass {
    Actions builder;

    @When("user clicked the myInfo tab and edit button")
    public void click_myInfo_and_edit() {
        builder = new Actions(webDriver);
        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement editBtn = webDriver.findElement(By.id("btnSave"));
        builder.click(editBtn).pause(3000).build().perform();

    }

    @Then("user entered the new values")
    public void enter_values() {
        WebElement firstName = webDriver.findElement(By.id("personal_txtEmpFirstName"));
        WebElement lastName = webDriver.findElement(By.id("personal_txtEmpLastName"));
        WebElement maleButton = webDriver.findElement(By.id("personal_optGender_1"));
        WebElement nationalitySelect = webDriver.findElement(By.id("personal_cmbNation"));
        Select selectNation = new Select(nationalitySelect);
        WebElement dob = webDriver.findElement(By.id("personal_DOB"));

        firstName.clear();
        firstName.sendKeys("First");
        lastName.clear();
        lastName.sendKeys("Last");
        maleButton.click();
        selectNation.selectByIndex(4);
        dob.clear();
        dob.sendKeys("2026-07-01");
    }

    @When("user clicks the save button")
    public void user_clicks_save() {
        WebElement btnSave = webDriver.findElement(By.id("btnSave"));
        builder.click(btnSave).pause(3000).build().perform();

    }

    @Then("user checked the updated name")
    public void verify_updated_info() {
        WebElement newName = webDriver.findElement(By.id("personal_txtEmpFirstName"));
        assertEquals(newName.getAttribute("value"), "First");
    }

}
