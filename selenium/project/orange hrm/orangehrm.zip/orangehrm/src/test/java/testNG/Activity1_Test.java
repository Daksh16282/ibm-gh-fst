package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;
public class Activity1_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp(){
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }


    @Test
    public void assertTitle(){
        assertEquals(webDriver.getTitle(), "OrangeHRM");
    }

    @AfterClass
    public void tearDown(){
        webDriver.quit();
    }
}
