package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity4_C extends BaseClass {

    Actions builder;

    @Given("user is on webpage and logged in")
    public void user_is_logged_in() {
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();

    }

    @When("user clicked the pim tab and add button")
    public void click_pim_and_add() {
        WebElement pimTab = webDriver.findElement(By.id("menu_pim_viewPimModule"));

        pimTab.click();
        WebElement addButton = webDriver.findElement(By.id("btnAdd"));
        addButton.click();

    }

    @Then("user entered the employee details and save")
    public void enter_employee_details() {

        WebElement firstName = webDriver.findElement(By.id("firstName"));
        WebElement lastName = webDriver.findElement(By.id("lastName"));
        WebElement employeeId = webDriver.findElement(By.id("employeeId"));
        firstName.sendKeys("First");
        lastName.sendKeys("Last");
        employeeId.sendKeys("16282");

        WebElement btnSave = webDriver.findElement(By.id("btnSave"));
        btnSave.click();

    }

    @When("user clicks the pim tab again")
    public void click_pim_again() {
        WebElement pimTab = webDriver.findElement(By.id("menu_pim_viewPimModule"));
        pimTab.click();

    }

    @Then("user clicked search button and enter the employee name")
    public void search_employee_name() {
        WebElement searchEmpField = webDriver.findElement(By.id("empsearch_employee_name_empName"));
        WebElement searchBtn = webDriver.findElement(By.id("searchBtn"));

        builder.sendKeys(searchEmpField, "First Last ").pause(3000).perform();
        builder.click(searchBtn).pause(3000).perform();

    }

    @Then("user fetched the previously entered employee name")
    public void verifyEmployeeAdded() {
        WebElement resultTable = webDriver.findElement(By.xpath("//table/tbody/tr"));
        List<WebElement> columns = resultTable.findElements(By.xpath("./td"));
        assertEquals(columns.size(), 8);
    }
}
