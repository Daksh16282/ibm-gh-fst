package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity7_C extends BaseClass{
    Actions builder;
    int oldSize;
     List<WebElement> results;

    @When("user clicked the myInfo tab")
    public void click_myInfo_tab(){
        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();
    }
    @Then("user clicked the qualifications tab,see old results and click add button")
    public void click_qualification_and_add(){
         builder = new Actions(webDriver);
        WebElement qualificationTab = webDriver.findElement(By.xpath("(//a[text()='Qualifications'])[2]"));
        builder.click(qualificationTab).pause(3000).build().perform();

        results = webDriver.findElements(By.xpath("//table[@class='table hover']/tbody/tr"));
        oldSize = results.size();

        WebElement addButton = webDriver.findElement(By.id("addWorkExperience"));
        builder.click(addButton).pause(3000).build().perform();

    }

    @Then("user entered the qualification details and save")
    public void enter_and_save_details(){
        WebElement companyName = webDriver.findElement(By.id("experience_employer"));
        WebElement jobTitle = webDriver.findElement(By.id("experience_jobtitle"));

        WebElement fromDate = webDriver.findElement(By.id("experience_from_date"));
        WebElement toDate = webDriver.findElement(By.id("experience_to_date"));

        companyName.sendKeys("IBM");
        jobTitle.sendKeys("QE");
        fromDate.clear();
        fromDate.sendKeys("2026-01-01");
        toDate.clear();
        toDate.sendKeys("2028-12-31");

        WebElement saveButton = webDriver.findElement(By.id("btnWorkExpSave"));
        builder.click(saveButton).pause(3000).build().perform();

        results = webDriver.findElements(By.xpath("//table[@class='table hover']/tbody/tr"));

        assertEquals(results.size(), oldSize + 1, "Old size is : " + oldSize);

    }
}
