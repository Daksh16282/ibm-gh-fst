package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

import java.util.List;

public class Activity9_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }

    @Test
    public void assertEmergencyContacts() {
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();

        WebElement myInfo = webDriver.findElement(By.id("menu_pim_viewMyDetails"));
        myInfo.click();

        WebElement emergencyContact = webDriver.findElement(By.xpath("//a[text()='Emergency Contacts']"));
        builder.click(emergencyContact).pause(3000).build().perform();

        List<WebElement> contacts = webDriver.findElements(By.xpath("//table/tbody/tr"));
        // for (WebElement contact : contacts) {
        // System.out.println(contact.getText());
        // }
        assertEquals(contacts.size(), 4);
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
