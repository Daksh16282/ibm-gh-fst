package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity3_C extends BaseClass {
    @When("user entered the credentials")
    public void user_enter_credentials() {
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");

    }

    @Then("user clicked the login button")
    public void click_login() {
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));
        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();
        clickLogin.perform();

    }

    @Then("user redirected to homepage")
    public void open_homepage() {
        assertEquals(webDriver.getCurrentUrl(), "https://hrm.alchemy.hguy.co/symfony/web/index.php/dashboard");

    }
}
