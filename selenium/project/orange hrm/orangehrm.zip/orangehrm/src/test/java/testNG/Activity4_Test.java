package testNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.*;

import java.util.List;

public class Activity4_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://hrm.alchemy.hguy.co/symfony/web/index.php/auth/login");
    }

    @Test
    public void assertLogIn() {
        WebElement userField = webDriver.findElement(By.id("txtUsername"));
        WebElement passwordField = webDriver.findElement(By.id("txtPassword"));
        WebElement loginButton = webDriver.findElement(By.id("btnLogin"));

        Actions builder = new Actions(webDriver);
        Action clickLogin = builder.click(loginButton).pause(5000).build();

        userField.sendKeys("orange");
        passwordField.sendKeys("5Nx#I6BK%r3$8vz0ch");
        clickLogin.perform();
        WebElement pimTab = webDriver.findElement(By.id("menu_pim_viewPimModule"));

        pimTab.click();
        WebElement addButton = webDriver.findElement(By.id("btnAdd"));
        addButton.click();

        WebElement firstName = webDriver.findElement(By.id("firstName"));
        WebElement lastName = webDriver.findElement(By.id("lastName"));
        WebElement employeeId = webDriver.findElement(By.id("employeeId"));
        firstName.sendKeys("First");
        lastName.sendKeys("Last");
        employeeId.sendKeys("16282");

        WebElement btnSave = webDriver.findElement(By.id("btnSave"));
        btnSave.click();
        // Refetch as previous reference become stale
        pimTab = webDriver.findElement(By.id("menu_pim_viewPimModule"));
        pimTab.click();
        WebElement searchEmpField = webDriver.findElement(By.id("empsearch_employee_name_empName"));
        WebElement searchBtn = webDriver.findElement(By.id("searchBtn"));

        builder.sendKeys(searchEmpField, "First Last ").pause(3000).perform();

        // searchEmpField.sendKeys("First Last");
        // searchBtn.click();
        builder.click(searchBtn).pause(3000).perform();

        WebElement resultTable = webDriver.findElement(By.xpath("//table/tbody/tr"));
        List<WebElement> columns = resultTable.findElements(By.xpath("./td"));
        assertEquals(columns.size(), 8);
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
