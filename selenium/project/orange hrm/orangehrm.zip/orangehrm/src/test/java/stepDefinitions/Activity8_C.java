package stepDefinitions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity8_C extends BaseClass{
    
        Actions builder = new Actions(webDriver);

    @When("user clicked the applyLeave box")
    public void clik_applyLeave(){
        WebElement applyLeave = webDriver.findElement(By.xpath("//span[text()='Apply Leave']"));
        builder.click(applyLeave).pause(3000).build().perform();
    }

    @Then("user selected the leavetype and duration")
    public void select_type_and_duration(){
        WebElement leaveType = webDriver.findElement(By.xpath("//select[@id='applyleave_txtLeaveType']"));
        Select leaveSelect = new Select(leaveType);

        WebElement fromDate = webDriver.findElement(By.id("applyleave_txtFromDate"));
        WebElement toDate = webDriver.findElement(By.id("applyleave_txtToDate"));

        leaveSelect.selectByIndex(1);
        fromDate.clear();
        String fromDateSent = "2026-08-10";
        fromDate.sendKeys(fromDateSent);
        toDate.clear();
        String toDateSent = "2028-12-31";
        toDate.sendKeys(toDateSent);

    }
    @Then("user clicked the apply button")
    public void click_apply(){
        WebElement applyBtn = webDriver.findElement(By.id("applyBtn"));
        builder.click(applyBtn).pause(8000).build().perform();

    }
    @When("user clicked myLeaves tab")
    public void click_my_leaves(){

        WebElement myLeaves = webDriver.findElement(By.id("menu_leave_viewMyLeaveList"));
        builder.click(myLeaves).pause(3000).build().perform();

    }

    @Then("applied leave status is shown")
    public void check_leave_status(){
        String status = "";
        List<WebElement> leaveTableRows = webDriver.findElements(By.xpath("//table/tbody/tr"));
        for (int i = 0; i < leaveTableRows.size() - 1; i++) {
            String dateVal = leaveTableRows.get(i).findElement(By.xpath("./td[1]/a")).getText();
            if (dateVal.substring(0, 10).equals("2026-08-10")) {
                status = leaveTableRows.get(i).findElement(By.xpath("./td[6]/a")).getText();
                System.out.println("Status is : " + status);
                System.out.println();
                break;
            }

        }
        assertEquals(status, "Cancelled(9.00)");

    }
}
