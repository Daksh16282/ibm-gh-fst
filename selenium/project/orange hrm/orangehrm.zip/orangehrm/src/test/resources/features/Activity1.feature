@activity1
Feature: Title Check
  Scenario: Check the title of page
    Given user opens the webpage
    Then   title is checked
