@activity2
Feature: Check Header URL

  Scenario: Check the url of the header of the page
    Given user opens the webpage
    Then url of header is printed
