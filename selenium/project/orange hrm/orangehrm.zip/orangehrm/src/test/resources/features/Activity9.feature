@activity9
Feature: Emergency Contacts

  Scenario: User checks available emergency contacts
    Given user is on webpage and logged in
    When user clicked the myInfo tab
    Then user clicked the emergencyContacts tab and see the results
