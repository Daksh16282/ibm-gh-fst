@activity6
Feature: Tab Existence

  Scenario: Check if directory tab exists
    Given user is on webpage and logged in
    When user clicked the directory tab
    Then user fetched the heading text and check value
