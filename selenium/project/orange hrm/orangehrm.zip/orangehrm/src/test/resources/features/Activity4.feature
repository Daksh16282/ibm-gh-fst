@activity4
Feature: Add Employee

  Scenario: User adds a new employee
    Given user is on webpage and logged in
    When user clicked the pim tab and add button
    Then user entered the employee details and save
    When user clicks the pim tab again
    Then user clicked search button and enter the employee name
    Then user fetched the previously entered employee name
