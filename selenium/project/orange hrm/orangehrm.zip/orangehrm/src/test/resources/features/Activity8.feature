@activity8
Feature: Apply Leave

  Scenario: User applied for the leave
    Given user is on webpage and logged in
    When user clicked the applyLeave box
    Then user selected the leavetype and duration
    Then user clicked the apply button
    When user clicked myLeaves tab
    Then applied leave status is shown
