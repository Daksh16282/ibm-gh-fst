@activity3
Feature: Check user login

  Scenario: User enter credentials and login successfully
    Given user opens the webpage
    When user entered the credentials
    Then user clicked the login button
    Then user redirected to homepage
