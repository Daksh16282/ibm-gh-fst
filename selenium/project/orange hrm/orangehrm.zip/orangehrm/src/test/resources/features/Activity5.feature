@activity5
Feature: Edit Info

  Scenario: User edits his information
    Given user is on webpage and logged in
    When user clicked the myInfo tab and edit button
    Then user entered the new values
    When user clicks the save button
    Then user checked the updated name
