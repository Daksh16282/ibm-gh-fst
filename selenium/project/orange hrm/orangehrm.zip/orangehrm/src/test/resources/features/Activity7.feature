@activity7
Feature: Add Qualification

  Scenario: User add to his qualification
    Given user is on webpage and logged in
    When user clicked the myInfo tab
    Then user clicked the qualifications tab,see old results and click add button
    Then user entered the qualification details and save
