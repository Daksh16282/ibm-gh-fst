import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Activity8 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");

        // ------------------Log In User--------------------------------------
        WebElement usernameField = webDriver.findElement(By.id("user_name"));
        WebElement passwordField = webDriver.findElement(By.id("username_password"));
        WebElement logInButton = webDriver.findElement(By.id("bigbutton"));
        usernameField.sendKeys("will");
        passwordField.sendKeys("will");

        Actions builder = new Actions(webDriver);
        Action clickLogIn = builder.click(logInButton).pause(Duration.ofSeconds(5)).build();
        clickLogIn.perform();
        // --------------------------------------------------------------------------------------

        WebElement salesTab = webDriver.findElement(By.id("grouptab_0"));
        salesTab.click();

        WebElement accountsTab = webDriver.findElement(By.xpath("//a[text()='Accounts']"));
        accountsTab.click();

        By tablePath = By.xpath("//table[@class='list view table-responsive']/tbody/tr");
        wait.until(ExpectedConditions.visibilityOfElementLocated(tablePath));
        List<WebElement> tableRows = webDriver.findElements(tablePath);
        List<String> names = new ArrayList<>();

        int count = 0;
        for (int i = 0; i < tableRows.size(); i++) {
            if (count == 5) {
                break;
            }
            // As indexing is from 0 so odd ones occur at even indices
            if (i % 2 == 0) {
                String userName = tableRows.get(i).findElement(By.xpath("./td[3]")).getText();
                System.out.println(userName);
                names.add(userName);

                count++;
            }
        }
        System.out.println();
        System.out.println(names);
        webDriver.quit();
    }
}
