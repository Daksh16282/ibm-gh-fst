import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Activity7 {
    public static void main(String[] args) {

        WebDriver webDriver = new FirefoxDriver();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");

        // ------------------Log In User--------------------------------------
        WebElement usernameField = webDriver.findElement(By.id("user_name"));
        WebElement passwordField = webDriver.findElement(By.id("username_password"));
        WebElement logInButton = webDriver.findElement(By.id("bigbutton"));
        usernameField.sendKeys("will");
        passwordField.sendKeys("will");

        Actions builder = new Actions(webDriver);
        Action clickLogIn = builder.click(logInButton).pause(Duration.ofSeconds(5)).build();
        clickLogIn.perform();
        // --------------------------------------------------------------------------------------

        WebElement salesTab = webDriver.findElement(By.id("grouptab_0"));
        salesTab.click();

        WebElement leadsTab = webDriver.findElement(By.xpath("//a[text()='Leads']"));
        leadsTab.click();

        WebElement additionalInfoElement = webDriver
                .findElement(By.xpath("//span[@title='Additional Details'][1]"));
        additionalInfoElement.click();

        WebElement phoneNo = webDriver.findElement(By.xpath("//span[@class='phone']"));
        System.out.println("Phone number : " + phoneNo.getText());
        webDriver.quit();
    }
}
