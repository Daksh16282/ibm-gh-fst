import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Activity2 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
        By headerPath = By.xpath("//img[@alt = 'SuiteCRM']");
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(headerPath));
        WebElement headerImage = webDriver.findElement(headerPath);
        System.out.println(headerImage.getAttribute("src"));
        webDriver.quit();
    }
}
