import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Activity1 {
    public static void main(String[] args) {
        WebDriver webDriver = new FirefoxDriver();
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
        System.out.println("Title is : " + webDriver.getTitle());
        webDriver.quit();
    }
}
