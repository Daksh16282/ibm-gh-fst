@activity4
Feature: Login User

  Scenario: Check if user is loggedIn
    Given user opens the webpage
    When user enter credentials and click login
    Then user redirected to homepage
