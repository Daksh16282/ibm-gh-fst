@activity9
Feature: Lead Names

  Scenario: Fetch first 10 lead values under names and user column
    Given user opens the webpage and login
    When user click the sales tab
    Then user clicks the leads tab
    Then leads names and users are printed
