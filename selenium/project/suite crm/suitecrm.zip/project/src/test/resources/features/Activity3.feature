@activity3
Feature: FooterCheck

  Scenario: Check the first footerText of the webpage
    Given user opens the webpage
    Then footerText is checked
