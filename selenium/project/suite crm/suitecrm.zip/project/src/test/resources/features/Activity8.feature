@activity8
Feature: Account Names

  Scenario: Fetch first 5 account names at odd positions
    Given user opens the webpage and login
    When user click the sales tab
    Then user clicks the accounts tab
    Then account names are printed
