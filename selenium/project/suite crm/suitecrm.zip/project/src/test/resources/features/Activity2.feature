@activity2
Feature: SourceCheck

  Scenario: Check the url of the image
    Given user opens the webpage
    Then imageSrc is checked
