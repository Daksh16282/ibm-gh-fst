@activity6
Feature: Tab existence

  Scenario: Check if activities tab exists
    Given user opens the webpage and login
    Then checks if activity tab present
