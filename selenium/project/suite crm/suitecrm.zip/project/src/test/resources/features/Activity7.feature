@activity7
Feature: Phone Number

  Scenario: Fetch phone number of 1st lead from sales
    Given user opens the webpage and login
    When user click the sales tab
    Then user clicks the leads tab
    Then user clicks the additional info button
    Then phone number is appeared
