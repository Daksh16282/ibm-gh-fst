@activity5
Feature: Header Color

  Scenario: Check the color of homepage header
    Given user opens the webpage and login
    Then user checks header color
