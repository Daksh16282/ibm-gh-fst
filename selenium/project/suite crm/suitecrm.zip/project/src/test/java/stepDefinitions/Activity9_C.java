package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;

public class Activity9_C extends BaseClass {

    @Then("leads names and users are printed")
    public void print_leads_values() {
        By tablePath = By.xpath("//table[@class='list view table-responsive']/tbody/tr");
        wait.until(ExpectedConditions.visibilityOfElementLocated(tablePath));
        List<WebElement> tableRows = webDriver
                .findElements(tablePath);
        List<String> leadData = new ArrayList<>();

        int count = 0;
        for (int i = 0; i < tableRows.size(); i++) {
            if (count == 10) {
                break;
            }
            String nameValue = tableRows.get(i).findElement(By.xpath("./td[3]")).getText();
            String userValue = tableRows.get(i).findElement(By.xpath("./td[3]")).getText();
            leadData.add("Name : " + nameValue + "  User : " + userValue);
            count++;
        }

        assertEquals(leadData.size(), 10);
    }
}
