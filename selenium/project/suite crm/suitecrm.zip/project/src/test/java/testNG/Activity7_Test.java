package testNG;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity7_Test {

    WebDriver webDriver;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
    }

    @Test
    public void getPhoneNumber() {
        WebElement usernameField = webDriver.findElement(By.id("user_name"));
        WebElement passwordField = webDriver.findElement(By.id("username_password"));
        WebElement logInButton = webDriver.findElement(By.id("bigbutton"));
        usernameField.sendKeys("will");
        passwordField.sendKeys("will");

        Actions builder = new Actions(webDriver);
        Action clickLogIn = builder.click(logInButton).pause(Duration.ofSeconds(5)).build();
        clickLogIn.perform();
        WebElement salesTab = webDriver.findElement(By.id("grouptab_0"));
        salesTab.click();

        WebElement leadsTab = webDriver.findElement(By.xpath("//a[text()='Leads']"));
        leadsTab.click();

        WebElement additionalInfoElement = webDriver
                .findElement(By.xpath("//span[@title='Additional Details'][1]"));
        additionalInfoElement.click();

        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[@class='phone']")));
        WebElement phoneNo = webDriver.findElement(By.xpath("//span[@class='phone']"));
        assertEquals(phoneNo.getText(), "(922) 612-2203");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
