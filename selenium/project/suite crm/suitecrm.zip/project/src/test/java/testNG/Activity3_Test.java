package testNG;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity3_Test {

    WebDriver webDriver;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
    }

    @Test
    public void checkFooterText() {
        By footerXPath = By.id("admin_options");
        WebElement footerText = webDriver.findElement(footerXPath);
        System.out.println();
        assertEquals(footerText.getText(),
                "© Supercharged by SuiteCRM");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
