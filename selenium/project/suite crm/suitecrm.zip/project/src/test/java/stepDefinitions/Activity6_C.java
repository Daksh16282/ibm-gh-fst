package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.Then;

public class Activity6_C extends BaseClass{
    

    @Then("checks if activity tab present")
    public void check_activity_tab_presence(){
 WebElement activitiesTab = webDriver
                .findElement(By.id("grouptab_3"));
        assertEquals(activitiesTab.getText(), "ACTIVITIES");
    }
}
