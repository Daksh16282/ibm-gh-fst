package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;

public class Activity2_C extends BaseClass {
    
      @Then("imageSrc is checked")
    public void checkImgSource() {
        By headerPath = By.xpath("//img[@alt = 'SuiteCRM']");
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(headerPath));
        WebElement headerImage = webDriver.findElement(headerPath);
        assertEquals(headerImage.getAttribute("src"),
                "https://demo.suiteondemand.com/themes/default/images/company_logo.png?v=2LAafPFfHgOiO1UB1J6bNg");
    }
}
