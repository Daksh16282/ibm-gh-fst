package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Then;

public class Activity3_C extends BaseClass{
    
    @Then("footerText is checked")
    public void checkFooterText(){
          By footerXPath = By.id("admin_options");
        WebElement footerText = webDriver.findElement(footerXPath);
        System.out.println();
        assertEquals(footerText.getText(),
                "© Supercharged by SuiteCRM");
    }
}
