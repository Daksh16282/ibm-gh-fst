package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Activity4_C extends BaseClass{
    
    @When("user enter credentials and click login")
    public void enter_credentials_and_proceed(){
         WebElement usernameField = webDriver.findElement(By.id("user_name"));
        WebElement passwordField = webDriver.findElement(By.id("username_password"));
        WebElement logInButton = webDriver.findElement(By.id("bigbutton"));
        usernameField.sendKeys("will");
        passwordField.sendKeys("will");

        Actions builder = new Actions(webDriver);
        Action clickLogIn = builder.click(logInButton).pause(Duration.ofSeconds(5)).build();
        clickLogIn.perform();
    }

    @Then("user redirected to homepage")
    public void verify_homepage_opened(){
        assertEquals(webDriver.getCurrentUrl(),
                "https://demo.suiteondemand.com/index.php?module=Home&action=Demo");
    }

}
