package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;

public class Activity1_Test {

    WebDriver webDriver;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
    }

    @Test
    public void assertTitle() {
        assertEquals(webDriver.getTitle(), "SuiteCRM Demo");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }

}
