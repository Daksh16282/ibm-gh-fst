package stepDefinitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Activity7_C extends BaseClass{
    
    @When("user click the sales tab")
    public void user_clicks_sales_tab(){
        WebElement salesTab = webDriver.findElement(By.id("grouptab_0"));
        salesTab.click();
    }
    
    @Then("user clicks the leads tab")
    public void user_clicks_leads_tab(){
        WebElement leadsTab = webDriver.findElement(By.xpath("//a[text()='Leads']"));
        leadsTab.click();
    }
    @Then("user clicks the additional info button")
    public void user_clicks_additional_info(){
        
        WebElement additionalInfoElement = webDriver
                .findElement(By.xpath("//span[@title='Additional Details'][1]"));
        additionalInfoElement.click();
    }

    @Then("phone number is appeared")
    public void getPhoneNumber() {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[@class='phone']")));
        WebElement phoneNo = webDriver.findElement(By.xpath("//span[@class='phone']"));
        assertEquals(phoneNo.getText(), "(135) 566-9226");
    }
}
