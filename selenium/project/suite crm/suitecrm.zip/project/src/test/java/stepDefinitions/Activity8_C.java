package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Then;

public class Activity8_C extends BaseClass {

    @Then("user clicks the accounts tab")
    public void user_clicks_leads_tab() {
        WebElement leadsTab = webDriver.findElement(By.xpath("//a[text()='Leads']"));
        leadsTab.click();
    }

    @Then("account names are printed")
    public void get_account_names() {
        By tablePath = By.xpath("//table[@class='list view table-responsive']/tbody/tr");
        wait.until(ExpectedConditions.visibilityOfElementLocated(tablePath));
        List<WebElement> tableRows = webDriver.findElements(tablePath);
        List<String> names = new ArrayList<>();
        int count = 0;
        for (int i = 0; i < tableRows.size(); i++) {
            if (count == 5) {
                break;
            }
            // As indexing is from 0 so odd ones occur at even indices
            if (i % 2 == 0) {
                String userName = tableRows.get(i).findElement(By.xpath("./td[3]")).getText();
                names.add(userName);
                count++;
            }
        }
        assertEquals(names.size(), 5);
    }
}
