package testNG;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Activity2_Test {

    WebDriver webDriver;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() {
        webDriver = new FirefoxDriver();
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(10));
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
    }

    @Test
    public void checkImgSource() {
        By headerPath = By.xpath("//img[@alt = 'SuiteCRM']");
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(headerPath));
        WebElement headerImage = webDriver.findElement(headerPath);
        assertEquals(headerImage.getAttribute("src"),
                "https://demo.suiteondemand.com/themes/default/images/company_logo.png?v=iFM-fyc7wxes7nQr-LNrMg");
    }

    @AfterClass
    public void tearDown() {
        webDriver.quit();
    }
}
