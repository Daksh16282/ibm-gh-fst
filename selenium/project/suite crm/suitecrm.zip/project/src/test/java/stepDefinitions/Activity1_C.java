package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Activity1_C extends BaseClass{
    
    @Given("user opens the webpage")
    public void openWebpage(){
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");
    }

    @Then("title is checked")
    public void assertTitle() {
        assertEquals(webDriver.getTitle(), "SuiteCRM Demo");
    }
}
