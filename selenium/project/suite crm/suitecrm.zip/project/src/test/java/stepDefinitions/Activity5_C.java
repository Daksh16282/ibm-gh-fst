package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Activity5_C extends BaseClass{
   
    @Given("user opens the webpage and login")
    public void user_is_logged_in(){
        webDriver.get("https://demo.suiteondemand.com/index.php?module=Users&action=Login");

        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("user_name")));
        WebElement usernameField = webDriver.findElement(By.id("user_name"));
        WebElement passwordField = webDriver.findElement(By.id("username_password"));
        WebElement logInButton = webDriver.findElement(By.id("bigbutton"));
        usernameField.sendKeys("will");
        passwordField.sendKeys("will");

        Actions builder = new Actions(webDriver);
        Action clickLogIn = builder.click(logInButton).pause(Duration.ofSeconds(5)).build();
        clickLogIn.perform();
    }

    @Then("user checks header color")
    public void getHeaderColor() {
        WebElement topHeader = webDriver
                .findElement(By.id("toolbar"));
        assertEquals(topHeader.getCssValue("color"), "rgb(83, 77, 100)");
    }
}
